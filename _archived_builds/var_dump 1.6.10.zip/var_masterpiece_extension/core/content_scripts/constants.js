const var_dump_extension_DEADBEEF = {
  ACTIONS: {
    getAllOptions: "getAllOptions",
    displayVarDump: "displayVarDump", // This is hardcoded in serviceWorker as well
    openOptionsPage: "openOptionsPage",
  },
};
