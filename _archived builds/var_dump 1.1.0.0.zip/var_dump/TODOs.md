#TODO's

##Bugs/Broken
- [x] Stop JS Error on all pages! -1.0.0.6-
- [ ] Stop JS Errors on non-dumpable pages
- [x] float's dont work! -1.0.0.3-
- [x] quotes withing strings cause chaos -1.0.0.3-

##Efficiency
###Next to Change!
1. DONE -1.0.0.3- Remove all the clear both's
2. Remove jquery dependence
3. Consolidate builds into single file
4. Minify!

##Functionality
1. Also parse print_r()'s
2. Also parse var_exports
3. DONE -1.0.0.4- Optional coloring
4. Informative Error Messging On Parse Fail/Invalid input
5. ~~button on chrome home screen to allow copy and paste of var_dump text~~
