//send of async request for colors right away
var COLORS;
var AUTORUN;
var CASCADE;
var DEBUG_PRINTJSON = false;
var SPECIAL_CLASS = "DEADBEEF"; //also must change in scss
var KEY_TEXT = ": "; //"=&gt;"