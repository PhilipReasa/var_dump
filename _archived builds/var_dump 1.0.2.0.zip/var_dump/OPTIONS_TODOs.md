#OPTIONS TODO's

##Features to add
- [ ] Have "close" also close tags below it
- [x] Color preferences/changes
- [ ] Auto run option
- [ ] add pre tags to escape potential html